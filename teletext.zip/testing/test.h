#include <SDL.h>
#include <math.h>
#include "teletext.h"

void test_Read_telefile(void);
void test_Setting_Board(void);
void test_Default_Setting(teletext b[BOARDHEIGHT][BOARDWIDTH]);
void test_set_unit(teletext b[BOARDHEIGHT][BOARDWIDTH]);
void test_Display_Board(void);
