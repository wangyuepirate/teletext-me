#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "test.h"

int main(void)
{
   printf("Beginning BST Test ...\n");
   test_Read_telefile();
   test_Setting_Board();
   test_Display_Board();

   printf("Finished BST Test ...\n");
   return 0;
}


void test_Read_telefile(void)
{
   int i,j;
   teletext b[BOARDHEIGHT][BOARDWIDTH];
   Read_telefile("test.m7",b); 
   for(i=0;i<BOARDHEIGHT;i++){
      for(j=0;j<BOARDWIDTH;j++){
         assert(b[i][j].character >= TELESTART);
      }
   }
  /*choose some random location to check characters*/
   assert(b[0][0].character == 0xa0);
   assert(b[0][9].character == 0xc5);
   assert(b[1][39].character == 0xb2);
   assert(b[2][12].character == 0x8d);
   assert(b[9][38].character == 0x87);
   assert(b[15][19].character == 0x9d);
}

void test_Setting_Board(void)
{

   teletext b[BOARDHEIGHT][BOARDWIDTH];
   Read_telefile("test.m7",b);
   Setting_Board(b);
   test_Default_Setting(b);
   test_set_unit(b);
}

void test_Default_Setting(teletext b[BOARDHEIGHT][BOARDWIDTH])
{
   int i,j=0;
   /*besides some special lines,make sure every newline is automatically set*/ 
   for(i=0;i<BOARDHEIGHT && i!=15 && i!=16;i++){ 
      assert(b[i][j].set.foreground == white);
      assert(b[i][j].set.mode ==alphanumeric);
      assert(b[i][j].set.background == black);
      assert(b[i][j].set.height == singleh);
      assert(b[i][j].set.holdmode == release);
   }
   assert(b[15][0].set.foreground == cyan);
   assert(b[16][0].set.foreground == cyan);
}

void test_set_unit(teletext b[BOARDHEIGHT][BOARDWIDTH])
{
   /*choose some control code,make sure after them,elements are set */
   /*set alphanumeric/graphic color*/
   assert(b[5][1].set.foreground != red);   
   assert(b[5][2].set.foreground == red);
   assert(b[5][3].set.foreground == red);

   assert(b[18][1].set.foreground == white);
   assert(b[18][2].set.foreground == white);

  /*set height*/
   assert(b[2][11].set.height == singleh);
   assert(b[2][12].set.height == doubleh);
   assert(b[2][13].set.height == doubleh);

   /*set background color*/
   assert(b[13][2].set.background != cyan);
   assert(b[13][3].set.background == cyan);
   assert(b[13][4].set.background == cyan);

   /*set mode*/
   assert(b[18][0].set.mode != con_gra);
   assert(b[18][1].set.mode == con_gra);
   assert(b[18][2].set.mode == con_gra);
   
   assert(b[18][11].set.mode != sep_gra);
   assert(b[18][12].set.mode == sep_gra);
   assert(b[18][13].set.mode == sep_gra);

   /*set holdmode*/
   assert(b[18][29].set.holdmode == release);
   assert(b[18][30].set.holdmode == hold);
   assert(b[18][30].character == b[18][29].character);
   assert(b[18][31].character == b[18][29].character);
   assert(b[18][31].set.foreground == red);
   assert(b[18][37].set.holdmode == release);
}

void test_Display_Board(void)
{
   teletext b[BOARDHEIGHT][BOARDWIDTH];
   Read_telefile("test.m7",b);
   Setting_Board(b);
   Display_Board(b);
   Read_telefile("test2.m7",b);
   Setting_Board(b);
   Display_Board(b);
}

