#include "teletext.h"


void Read_telefile(char *filename, teletext b[BOARDHEIGHT][BOARDWIDTH])
{
   FILE *fp;
   int i,j,num;
   fp=fopen(filename,"rb");
   if(fp == NULL){
      ON_ERROR("Cannot open File\n");
   }
   for(i=0;i<BOARDHEIGHT;i++){
      for(j=0;j<BOARDWIDTH;j++){
         num=fread(&b[i][j].character,sizeof(unsigned char),1,fp);
         if(num != 1){
            ON_ERROR("Fread Error\n");
         }
         /*make sure characters are 7-bit*/
         if(b[i][j].character < TELESTART){
            b[i][j].character += TELESTART;           
         }
      }
    }
    fclose(fp);
    return ;
}

void Setting_Board(teletext b[BOARDHEIGHT][BOARDWIDTH])
{
   int i,j;
   Setting new;
   held_gra last_gra;
   for(i=0;i<BOARDHEIGHT;i++){
      Default_Setting(&new);
      for(j=0;j<BOARDWIDTH;j++){
         b[i][j]=set_unit(b[i][j],&last_gra,&new);
      }
   }
   return;
  
}


teletext set_unit(teletext t,held_gra *last,Setting *s)
{
   if(t.character >= red && t.character <= white){
      s->foreground = t.character;
      s->mode = alphanumeric;
   }
   if(t.character == doubleh){
      s->height = doubleh;
      s->mode = alphanumeric;
      s->holdmode = release;
   }
   if(t.character == singleh){
      s->height = singleh;
      s->mode = alphanumeric;
      s->holdmode = release;
   }
   if(t.character-G_A >= red && t.character-G_A <= white){
      s->foreground = t.character-G_A;
      s->mode = con_gra;
   }
   if(t.character == con_gra){
      s->mode = con_gra;
      s->holdmode = release;
   }
   if(t.character == sep_gra){
      s->mode = sep_gra;
      s->holdmode = release;
   }
   if(t.character == black){
      s->background = black;
   } 
   if(t.character == newbgc){
      s->background = s->foreground;
   }
   if(t.character == hold){
      s->holdmode = hold;
   }
   if(t.character == release){
      s->holdmode = release;
   }
   if(t.character >= SIXELST1){
      last->character = t.character;
      last->mode = t.set.mode;
   }
   t.set.mode = s->mode;
   t.set.foreground=s->foreground;
   t.set.background=s->background;
   t.set.height = s->height;
   t.set.holdmode = s->holdmode;
   /*save last graphic symbol for holdmode*/
   if(t.character >= SIXELST1){
      last->character = t.character;
      last->mode = t.set.mode;
   }
   /*in holdmode,change its character to preserve graphic*/ 
   if(t.set.holdmode == hold){
      t.character = last->character;
      t.set.mode = last->mode;
   }
   return t;
}

void Default_Setting(Setting *newset)
{
    newset->mode =alphanumeric;
    newset->foreground = white;
    newset->background = black;
    newset->height = singleh;
    newset->holdmode = release;
}

void Display_Board(teletext b[BOARDHEIGHT][BOARDWIDTH])
{
   fntrow fontdata[FNTCHARS][FNTHEIGHT];
   int i,j;
   SDL_Simplewin sw;
   tele_SDL_Init(&sw);
   tele_SDL_ReadFont(fontdata);
   for(i=0;i<BOARDHEIGHT;i++){
      for(j=0;j<BOARDWIDTH;j++){
          Draw_unit(&sw,fontdata,b[i][j],i,j,b[i+1][j].set.height);
       }
   }
   SDL_RenderPresent(sw.renderer);
   while(!sw.finished){
   tele_SDL_Events(&sw);
   }
   atexit(SDL_Quit);
}

   

void Draw_unit(SDL_Simplewin *sw,fntrow fontdata[FNTCHARS][FNTHEIGHT],teletext t,int i,int j,Height nextrow)
{
   /*the last line does not have nextrow,so set to single height*/
   if(i == BOARDHEIGHT - 1){
      nextrow = singleh;
   }

   if(t.set.holdmode == release){ 
      if(t.character >= TELESTART && t.character <= TELECONTROLEND){
         tele_SDL_DrawSpace(sw,t,i,j);
         return;
      }
   }
   /*if background is not black, draw background*/
   if(t.set.background != black){
      tele_SDL_DrawSpace(sw,t,i,j);
   }

   if(t.set.mode == con_gra || t.set.mode == sep_gra){
      if((t.character >= SIXELST1 && t.character <= SIXELEN1) || (t.character >= SIXELST2)){
         Draw_Graphic(sw,t,i,j);
         return;
         }  
    }
                        
   if(t.set.height == singleh){
         tele_SDL_DrawChar_S(sw, fontdata,t,j*FNTWIDTH,i*FNTHEIGHT);
   }
   if(t.set.height == doubleh){
      if(nextrow == doubleh){
         tele_SDL_DrawChar_Dup(sw, fontdata,t,j*FNTWIDTH,i*FNTHEIGHT);
      }
      else{
         tele_SDL_DrawChar_Ddown(sw, fontdata,t,j*FNTWIDTH,i*FNTHEIGHT);
      }
   }
   return;                 
}

void Draw_Graphic(SDL_Simplewin *sw,teletext t,int i,int j)
{
   sixel gra;
   int code;
   
   code = t.character-SIXELST1;
   gra.rt3 = code / S_RT3;
   code = code % S_RT3;
   gra.lf3 = code / S_LF3;
   code = code % S_LF3;

   gra.rt2 = code / S_RT2;
   code = code % S_RT2;
   gra.lf2 = code / S_LF2;
   code = code % S_LF2;

   gra.rt1 = code / S_RT1;
   code = code % S_RT1;
   gra.lf1 = code / S_LF1;
  
   Light_Sixel(sw,t,gra,i,j);
}


void Light_Sixel(SDL_Simplewin *sw,teletext t,sixel gra,int i,int j)
{
   int x=j*FNTWIDTH;
   int y=i*FNTHEIGHT;
   if(gra.lf1){
      tele_SDL_DrawSixel(sw,t,x,y+SIXEL_AXIS_0*SIXELHEIGHT);
   }
   if(gra.rt1){
      tele_SDL_DrawSixel(sw,t,x+SIXELWIDTH,y+SIXEL_AXIS_0*SIXELHEIGHT);
   }

   if(gra.lf2){
      tele_SDL_DrawSixel(sw,t,x,y+SIXEL_AXIS_1*SIXELHEIGHT);
   }
   if(gra.rt2){
      tele_SDL_DrawSixel(sw,t,x+SIXELWIDTH,y+SIXEL_AXIS_1*SIXELHEIGHT);
   }

   if(gra.lf3){
      tele_SDL_DrawSixel(sw,t,x,y+SIXEL_AXIS_2*SIXELHEIGHT);
   }
   if(gra.rt3){
      tele_SDL_DrawSixel(sw,t,x+SIXELWIDTH,y+SIXEL_AXIS_2*SIXELHEIGHT);
   }
}


void tele_SDL_DrawSixel(SDL_Simplewin *sw,teletext t,int x,int y)
{
   SDL_Rect rect;
   rect.x = x;
   rect.y = y;
   if(t.set.mode == sep_gra ){
      rect.w = SIXELWIDTH - FRAMEWIDTH;
      rect.h =SIXELHEIGHT - FRAMEWIDTH;
   }
   else{
   rect.w = SIXELWIDTH;
   rect.h = SIXELHEIGHT;
   }
   Set_Color(sw,t.set.foreground);
   if(SDL_RenderFillRect(sw->renderer,&rect) !=0){
        fprintf(stderr, "\nUnable to fill Rectangle %s\n", SDL_GetError());
        SDL_Quit();
        exit(1);
  }

}


/*draw teletext-0xa0*/
void tele_SDL_DrawSpace(SDL_Simplewin *sw,teletext t,int i,int j)
{
   SDL_Rect rect;
   rect.x = j*FNTWIDTH;
   rect.y = i*FNTHEIGHT;
   rect.w = FNTWIDTH;
   rect.h = FNTHEIGHT;
   Set_Color(sw,t.set.background);
   if(SDL_RenderFillRect(sw->renderer,&rect) !=0){
        fprintf(stderr, "\nUnable to fill Rectangle %s\n", SDL_GetError());
        SDL_Quit();
        exit(1);
  }
}

   
/*draw double height character-up,ix:inside_x,ox:outside_x*/
void tele_SDL_DrawChar_Dup(SDL_Simplewin *sw, fntrow fontdata[FNTCHARS][FNTHEIGHT],teletext t, int ox, int oy)
{
   unsigned ix, iy;
   unsigned char chr;
   chr = t.character-TELESTART;
   for(iy = 0; iy < FNTHEIGHT/2; iy++){
      for(ix = 0; ix < FNTWIDTH; ix++){
         if(fontdata[chr-FNT1STCHAR][iy] >> (FNTWIDTH - 1 - ix) & 1){
            tele_SDL_DrawChar_Double(sw,t,ox+ix,oy+2*iy);
         }
      }
   }
}

/*draw double height character-down*/
void tele_SDL_DrawChar_Ddown(SDL_Simplewin *sw, fntrow fontdata[FNTCHARS][FNTHEIGHT],teletext t, int ox, int oy)
{
   unsigned ix, iy;
   unsigned char chr;
   chr = t.character-TELESTART;
   for(iy = FNTHEIGHT/2; iy < FNTHEIGHT; iy++){
      for(ix = 0; ix < FNTWIDTH; ix++){
         if(fontdata[chr-FNT1STCHAR][iy] >> (FNTWIDTH - 1 - ix) & 1){
            tele_SDL_DrawChar_Double(sw,t,ox+ix,oy+2*(iy-FNTHEIGHT/2));
         }
      }
   }
}

void tele_SDL_DrawChar_Double(SDL_Simplewin *sw,teletext t,int x,int y)
{
   SDL_Rect rect;
   rect.x = x;
   rect.y = y;
   rect.w = CHRWIDTH;
   rect.h = DOUBLE_CHRHEIGHT;
   Set_Color(sw,t.set.foreground);
   if(SDL_RenderFillRect(sw->renderer,&rect) !=0){
        fprintf(stderr, "\nUnable to fill Rectangle %s\n", SDL_GetError());
        SDL_Quit();
        exit(1);
  }
}


void tele_SDL_Init(SDL_Simplewin *sw)
{

   sw->finished = 0;
   
   sw->win= SDL_CreateWindow("Teletext",
                          SDL_WINDOWPOS_UNDEFINED,
                          SDL_WINDOWPOS_UNDEFINED,
                          WWIDTH, WHEIGHT,
                          SDL_WINDOW_SHOWN);
   if(sw->win == NULL){
      fprintf(stderr, "\nUnable to initialize SDL Window:  %s\n", SDL_GetError());
      SDL_Quit();
      exit(1);
   }

   sw->renderer = SDL_CreateRenderer(sw->win, -1, SDL_RENDERER_ACCELERATED);
   if(sw->renderer == NULL){
      fprintf(stderr, "\nUnable to initialize SDL Renderer:  %s\n", SDL_GetError());
      SDL_Quit();
      exit(1);
   }
   if(SDL_SetRenderDrawColor(sw->renderer, 0, 0, 0, SDL_ALPHA_OPAQUE) != 0){
        fprintf(stderr, "\nUnable to set RenderDrawColor  %s\n", SDL_GetError());
        SDL_Quit();
        exit(1);
   }
   if(SDL_RenderClear(sw->renderer) != 0){
        fprintf(stderr, "\nUnable to clear Render  %s\n", SDL_GetError());
        SDL_Quit();
        exit(1);
   }
   SDL_RenderPresent(sw->renderer);
}

void tele_SDL_ReadFont(fntrow fontdata[FNTCHARS][FNTHEIGHT])
{
    FILE *fp = fopen(FNTNAME, "rb");
    size_t itms;
    if(!fp){
       fprintf(stderr, "Can't open Font file \n");
       exit(1);
   }
   itms = fread(fontdata, sizeof(fntrow), FNTCHARS*FNTHEIGHT, fp);
   if(itms != FNTCHARS*FNTHEIGHT){
       fprintf(stderr, "Can't read all Font file (%d) \n", (int)itms);
       exit(1);
   }
   fclose(fp);
}



void tele_SDL_DrawChar_S(SDL_Simplewin *sw, fntrow fontdata[FNTCHARS][FNTHEIGHT],teletext t, int ox, int oy)
{
   unsigned ix, iy;
   unsigned char chr;
   chr = t.character-TELESTART;
   for(iy = 0; iy < FNTHEIGHT; iy++){
      for(ix = 0; ix < FNTWIDTH; ix++){
         if(fontdata[chr-FNT1STCHAR][iy] >> (FNTWIDTH - 1 - ix) & 1){
            Set_Color(sw,t.set.foreground);;
            if(SDL_RenderDrawPoint(sw->renderer, ix + ox, iy + oy) !=0){
               fprintf(stderr, "\nUnable to draw point %s\n", SDL_GetError());
               SDL_Quit();
               exit(1);
            }
         }
      }
   }
}

void Set_Color(SDL_Simplewin *sw,Color color)
{
  int err=0;
  if(color == black){
     if(SDL_SetRenderDrawColor(sw->renderer, 0, 0, 0, SDL_ALPHA_OPAQUE) !=0 ){
        fprintf(stderr, "\nUnable to Set RenderDrawColor  %s\n", SDL_GetError());
        SDL_Quit();
        exit(1);
     }
     err++;
  }
  if(color == red){
     if(SDL_SetRenderDrawColor(sw->renderer, 255, 0, 0, SDL_ALPHA_OPAQUE) !=0 ){
        fprintf(stderr, "\nUnable to Set RenderDrawColor  %s\n", SDL_GetError());
        SDL_Quit();
        exit(1);
     }
     err++;
  }
  if(color == green){
     if(SDL_SetRenderDrawColor(sw->renderer, 0, 255, 0, SDL_ALPHA_OPAQUE) !=0 ){
        fprintf(stderr, "\nUnable to Set RenderDrawColor  %s\n", SDL_GetError());
        SDL_Quit();
        exit(1);
     }
     err++;
  }
  if(color == yellow){
     if(SDL_SetRenderDrawColor(sw->renderer, 255, 255, 0, SDL_ALPHA_OPAQUE) !=0 ){
        fprintf(stderr, "\nUnable to Set RenderDrawColor  %s\n", SDL_GetError());
        SDL_Quit();
        exit(1);
     }
     err++;
  }
  if(color == blue){
     if(SDL_SetRenderDrawColor(sw->renderer, 0, 0, 255, SDL_ALPHA_OPAQUE) !=0 ){
        fprintf(stderr, "\nUnable to Set RenderDrawColor  %s\n", SDL_GetError());
        SDL_Quit();
        exit(1);
     }
     err++;
  }
  if(color == magenta){
     if(SDL_SetRenderDrawColor(sw->renderer, 255, 0, 255, SDL_ALPHA_OPAQUE) !=0 ){
        fprintf(stderr, "\nUnable to Set RenderDrawColor  %s\n", SDL_GetError());
        SDL_Quit();
        exit(1);
     }
     err++;
  }
  if(color == cyan){
     if(SDL_SetRenderDrawColor(sw->renderer, 0, 255, 255, SDL_ALPHA_OPAQUE) !=0){
        fprintf(stderr, "\nUnable to Set RenderDrawColor  %s\n", SDL_GetError());
        SDL_Quit();
        exit(1);
     }
     err++;
  }
  if(color == white){
     if(SDL_SetRenderDrawColor(sw->renderer, 255, 255, 255, SDL_ALPHA_OPAQUE) !=0){
        fprintf(stderr, "\nUnable to Set RenderDrawColor  %s\n", SDL_GetError());
        SDL_Quit();
        exit(1);
     }
     err++;
  }
  if(err !=1){
     fprintf(stderr, "\nSelect unknown color  %s\n", SDL_GetError());
     SDL_Quit();
     exit(1);
  }
}


void tele_SDL_Events(SDL_Simplewin *sw)
{
   SDL_Event event;
   while(SDL_PollEvent(&event)) 
   {      
       switch (event.type){
          case SDL_QUIT:
          case SDL_KEYDOWN:
             sw->finished = 1;
       }
    }
}











