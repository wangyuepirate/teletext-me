#include <stdio.h>
#include <stdlib.h>
#include "teletext.h"


void Display_in_HTML(char *name,teletext b[BOARDHEIGHT][BOARDWIDTH]);
void Create_Html(FILE **f,char *name);
void Begin_Html(FILE **f);

void Prnt_Html(FILE **f,teletext b[BOARDHEIGHT][BOARDWIDTH]);
void Prnt_Element(FILE **f,teletext b[BOARDHEIGHT][BOARDWIDTH],char *ele);
void Prnt_Statement(FILE **f,teletext b[BOARDHEIGHT][BOARDWIDTH],char *ele);
void Prnt_Sub_Element(FILE **f,teletext b[BOARDHEIGHT][BOARDWIDTH],char *ele);
void Prnt_teletext(FILE **f,teletext b[BOARDHEIGHT][BOARDWIDTH]);

void Start_Tag(FILE **f,char *tag);
void End_Tag(FILE **f,char *tag);


void Draw_unit_Html(FILE **f,fntrow fontdata[FNTCHARS][FNTHEIGHT],teletext t,int i,int j,Height nextrow);
void Set_Color_Html(FILE **f,Color color);
void DrawSpace_Html(FILE **f,teletext t,int i,int j);

void DrawGra_Html(FILE **f,teletext t,int i,int j);
void LightSixel_Html(FILE **f,teletext t,sixel gra,int i,int j);
void DrawSixel_Html(FILE **f,teletext t,int x,int y);

void DrawChar_Single_Html(FILE **f, fntrow fontdata[FNTCHARS][FNTHEIGHT],teletext t, int ox, int oy);
void DrawChar_Dup_Html(FILE **f, fntrow fontdata[FNTCHARS][FNTHEIGHT],teletext t, int ox, int oy);
void DrawChar_Ddown_Html(FILE **f, fntrow fontdata[FNTCHARS][FNTHEIGHT],teletext t, int ox, int oy);
