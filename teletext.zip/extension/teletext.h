#include <SDL.h>
#include <math.h>


#define ON_ERROR(STR) fprintf(stderr, STR); exit(EXIT_FAILURE);

#define BOARDHEIGHT 25
#define BOARDWIDTH 40

#define CHRWIDTH 1
#define CHRHEIGHT 1
#define DOUBLE_CHRHEIGHT (CHRHEIGHT*2)

#define COLORTEXTST 0x81
#define COLORTEXTEN 0x87


#define FNTNAME "m7fixed.fnt"
typedef unsigned short fntrow;
#define FNTWIDTH (sizeof(fntrow)*8)
#define FNTHEIGHT 18

#define FNTCHARS 96
#define FNT1STCHAR 32

#define FRAMEWIDTH 2

#define G_A (0x91-0x81)

#define SIXELST1 0xA0 
#define SIXELEN1 0xBF
#define SIXELST2 0xE0

#define S_RT3 64
#define S_LF3 16
#define S_RT2 8
#define S_LF2 4
#define S_RT1 2
#define S_LF1 1
#define SIXELHEIGHT FNTHEIGHT/3
#define SIXELWIDTH FNTWIDTH/2

#define SIXEL_AXIS_0 0
#define SIXEL_AXIS_1 1
#define SIXEL_AXIS_2 2

#define TELESTART 0x80
#define TELECONTROLEND 0x9F
#define TELEEND 0xFF

#define WWIDTH BOARDWIDTH*FNTWIDTH
#define WHEIGHT BOARDHEIGHT*FNTHEIGHT

typedef enum Mode{alphanumeric,con_gra=0x99,sep_gra} Mode;
typedef enum Color{black=0x9c,newbgc,red=0x81,green,yellow,blue,magenta,cyan,white} Color;
typedef enum Height{singleh=0x8C,doubleh} Height;
typedef enum Holdmode{hold=0x9E,release} Holdmode;
typedef enum Boolsixel{no,yes} Boolsixel;


struct SDL_Simplewin {
   SDL_bool finished;
   SDL_Window *win;
   SDL_Renderer *renderer;
};
typedef struct SDL_Simplewin SDL_Simplewin;

struct Setting {
   Mode mode;
   Color foreground;
   Color background;
   Height height;
   Holdmode holdmode;  
};

typedef struct Setting Setting;


struct teletext {
   unsigned char character;
   Setting set;   
};

typedef struct teletext teletext;

struct held_gra{
   unsigned char character;
   Mode mode;
};

typedef struct held_gra held_gra;

struct sixel{
   Boolsixel lf1;
   Boolsixel lf2;
   Boolsixel lf3;
   Boolsixel rt1;
   Boolsixel rt2;
   Boolsixel rt3;
};
typedef struct sixel sixel;   

void Read_telefile(char *filename, teletext b[BOARDHEIGHT][BOARDWIDTH]);
void Setting_Board(teletext b[BOARDHEIGHT][BOARDWIDTH]);


void Default_Setting(Setting *newset);
teletext set_unit(teletext t,held_gra *last,Setting *s);


void Draw_unit(SDL_Simplewin *sw,fntrow fontdata[FNTCHARS][FNTHEIGHT],teletext t,int i,int j,Height nextrow);
void tele_SDL_DrawChar_Dup(SDL_Simplewin *sw, fntrow fontdata[FNTCHARS][FNTHEIGHT],teletext t, int ox, int oy);
void tele_SDL_DrawChar_Ddown(SDL_Simplewin *sw, fntrow fontdata[FNTCHARS][FNTHEIGHT],teletext t, int ox, int oy);
void tele_SDL_DrawChar_Double(SDL_Simplewin *sw,teletext t,int x,int y);

void Draw_Graphic(SDL_Simplewin *sw,teletext t,int i,int j);
void Light_Sixel(SDL_Simplewin *sw,teletext t,sixel gra,int i,int j);
void tele_SDL_DrawSixel(SDL_Simplewin *sw,teletext t,int x,int y);
void tele_SDL_DrawSpace(SDL_Simplewin *sw,teletext t,int i,int j);
void Display_Board(teletext b[BOARDHEIGHT][BOARDWIDTH]);

void tele_SDL_Init(SDL_Simplewin *sw);
void tele_SDL_ReadFont(fntrow fontdata[FNTCHARS][FNTHEIGHT]);
void tele_SDL_DrawChar_S(SDL_Simplewin *sw, fntrow fontdata[FNTCHARS][FNTHEIGHT],teletext t, int ox, int oy);
void Set_Color(SDL_Simplewin *sw,Color color);
void tele_SDL_Events(SDL_Simplewin *sw);


