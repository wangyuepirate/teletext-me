#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "extension.h"

int main(int argc,char *argv[])
{
   teletext b[BOARDHEIGHT][BOARDWIDTH];
   if(argc != 2){
      ON_ERROR("The number of Input Error\n");
   } 
   Read_telefile(argv[1],b);   
   Setting_Board(b);
   Display_in_HTML(argv[1],b);

   return 0;
}


void Display_in_HTML(char *name,teletext b[BOARDHEIGHT][BOARDWIDTH])
{
   FILE *fhtml;
   Create_Html(&fhtml,name);
   Prnt_Html(&fhtml,b);
   return;
}

void Create_Html(FILE **f,char *name)
{
   strcat(name,"_html.html");
   *f=fopen(name,"w+");
   if(*f == NULL){
      ON_ERROR("Cannot create html file\n");
   }
   return;
}

void Prnt_Html(FILE **f,teletext b[BOARDHEIGHT][BOARDWIDTH])
{
   Start_Tag(f,"!DOCTYPE html");
   Prnt_Element(f,b,"html");
   fclose(*f);
}

void Prnt_Element(FILE **f,teletext b[BOARDHEIGHT][BOARDWIDTH],char *ele)
{
   Start_Tag(f,ele);
   Prnt_Statement(f,b,ele);
   Prnt_Sub_Element(f,b,ele);
   End_Tag(f,ele);
}

void Prnt_Sub_Element(FILE **f,teletext b[BOARDHEIGHT][BOARDWIDTH],char *ele)
{
   if(strcmp(ele,"html") == 0){
      Prnt_Element(f,b,"head");
      Prnt_Element(f,b,"body");
   }
   if(strcmp(ele,"head") == 0){
      Prnt_Element(f,b,"title");
      Prnt_Element(f,b,"style");
   }
   if(strcmp(ele,"body") == 0){
      Prnt_Element(f,b,"div");
   }
   if(strcmp(ele,"div") == 0){
      Prnt_Element(f,b,"h1");
      Prnt_Element(f,b,"canvas");
      Prnt_Element(f,b,"script");
   }
   return;
}



void Prnt_Statement(FILE **f,teletext b[BOARDHEIGHT][BOARDWIDTH],char *ele)
{
   if(strcmp(ele,"head") == 0){
      fprintf(*f,"<meta charset=\"utf-8\">\n");
   }
   if(strcmp(ele,"title") == 0){
      fprintf(*f,"Teletext_Extension_Html\n");
   }
   if(strcmp(ele,"style") == 0){
      Prnt_Statement(f,b,"container");
      Prnt_Statement(f,b,"tele_canvas");
   }
   if(strcmp(ele,"h1") == 0){
      fprintf(*f,"Teletext in Html\n");
   }
   if(strcmp(ele,"script") == 0){
      fprintf(*f,"var c=document.getElementById(\"tele_canvas\");\n");
      fprintf(*f,"var ctx=c.getContext(\"2d\");\n");
      Prnt_teletext(f,b);
   }
   if(strcmp(ele,"container") == 0){
      fprintf(*f,".container{\n");
      fprintf(*f,"margin:0 auto;\n");
      fprintf(*f,"width:%dpx;\n",WWIDTH);
      fprintf(*f,"border:2px dashed gray;\n");
      fprintf(*f,"}\n");
   }
   if(strcmp(ele,"tele_canvas") == 0){
      fprintf(*f,"#tele_canvas{\n");
      fprintf(*f,"background-color:black;\n");
      fprintf(*f,"}\n");
   }
   return;
}


void Start_Tag(FILE **f,char *tag)
{
   if(*f == NULL){
      ON_ERROR("Cannot Print Element Start Tag\n");
   }
   if(strcmp(tag,"style") == 0){
      fprintf(*f,"<style type=\"text/css\">\n");
      return;
  }
   if(strcmp(tag,"div") == 0){
      fprintf(*f,"<div class=\"container\">\n");
      return;
   }
   if(strcmp(tag,"h1") == 0){
      fprintf(*f,"<h1 style=\"text-align:center\">\n");
      return;
   }
   if(strcmp(tag,"canvas") == 0){
      fprintf(*f,"<canvas id=\"tele_canvas\" width=\"%d\" height=\"%d\">\n",WWIDTH,WHEIGHT);
      return;
   }
   if(strcmp(tag,"script") == 0){
      fprintf(*f,"<script type=\"text/javascript\">\n");
      return;
   }
   fprintf(*f,"<%s>\n",tag);
}

void End_Tag(FILE **f,char *tag)
{
   if(*f == NULL){
      ON_ERROR("Cannot Print Element End Tag\n");
   }
   fprintf(*f,"</%s>\n",tag);
}

void Prnt_teletext(FILE **f,teletext b[BOARDHEIGHT][BOARDWIDTH])
{
   int i,j;
   fntrow fontdata[FNTCHARS][FNTHEIGHT];
   tele_SDL_ReadFont(fontdata);
   for(i=0;i<BOARDHEIGHT;i++){
      for(j=0;j<BOARDWIDTH;j++){
          Draw_unit_Html(f,fontdata,b[i][j],i,j,b[i+1][j].set.height);
       }
   }
}


void Draw_unit_Html(FILE **f,fntrow fontdata[FNTCHARS][FNTHEIGHT],teletext t,int i,int j,Height nextrow)
{
   if(i == BOARDHEIGHT - 1){
      nextrow = singleh;
   }
   if(t.set.background != black){
      DrawSpace_Html(f,t,i,j);
   }
   if(t.set.holdmode == release){ 
      if(t.character >= TELESTART && t.character <= TELECONTROLEND){
         DrawSpace_Html(f,t,i,j);
         return;
      }
   }
   if(t.set.mode == con_gra || t.set.mode == sep_gra){
      if((t.character >= SIXELST1 && t.character <= SIXELEN1) || (t.character >= SIXELST2)){
         DrawGra_Html(f,t,i,j);
         return;
         }  
    }
   if(t.set.height == singleh){
         DrawChar_Single_Html(f, fontdata,t,j*FNTWIDTH,i*FNTHEIGHT);
   }
   if(t.set.height == doubleh){
      if(nextrow == doubleh){
         DrawChar_Dup_Html(f, fontdata,t,j*FNTWIDTH,i*FNTHEIGHT);
      }
      else{
         DrawChar_Ddown_Html(f, fontdata,t,j*FNTWIDTH,i*FNTHEIGHT);
      }
   }
   return; 
}

void DrawSpace_Html(FILE **f,teletext t,int i,int j)
{
   int rectx,recty,rectw,recth;
   rectx = j*FNTWIDTH;
   recty = i*FNTHEIGHT;
   rectw = FNTWIDTH;
   recth = FNTHEIGHT;
   Set_Color_Html(f,t.set.background);
   fprintf(*f,"ctx.fillRect(%d,%d,%d,%d);\n",rectx,recty,rectw,recth);
}

void Set_Color_Html(FILE **f,Color color)
{
  char *colortype;
  switch(color){
     case black:
        colortype = "\"black\"";
        break;
     case red:
        colortype = "\"red\"";
        break;
     case green:
        colortype = "\"green\"";
        break;
     case yellow:
        colortype = "\"yellow\"";
        break;
     case blue:
        colortype = "\"blue\"";
        break;
     case magenta:
        colortype = "\"magenta\"";
        break;
     case cyan:
        colortype = "\"cyan\"";
        break;
     case white:
        colortype = "\"white\"";
        break;
     default:
        ON_ERROR("Select unknown color\n");
   }
   fprintf(*f,"ctx.fillStyle=%s;\n",colortype);

}

void DrawGra_Html(FILE **f,teletext t,int i,int j)
{
   sixel gra;
   int code;
   
   code = t.character-SIXELST1;
   gra.rt3 = code / S_RT3;
   code = code % S_RT3;
   gra.lf3 = code / S_LF3;
   code = code % S_LF3;

   gra.rt2 = code / S_RT2;
   code = code % S_RT2;
   gra.lf2 = code / S_LF2;
   code = code % S_LF2;

   gra.rt1 = code / S_RT1;
   code = code % S_RT1;
   gra.lf1 = code / S_LF1;
  
   LightSixel_Html(f,t,gra,i,j);
}

void LightSixel_Html(FILE **f,teletext t,sixel gra,int i,int j)
{
   int x=j*FNTWIDTH;
   int y=i*FNTHEIGHT;
   if(gra.lf1){
      DrawSixel_Html(f,t,x,y+SIXEL_AXIS_0*SIXELHEIGHT);
   }
   if(gra.rt1){
      DrawSixel_Html(f,t,x+SIXELWIDTH,y+SIXEL_AXIS_0*SIXELHEIGHT);
   }

   if(gra.lf2){
     DrawSixel_Html(f,t,x,y+SIXEL_AXIS_1*SIXELHEIGHT);
   }
   if(gra.rt2){
      DrawSixel_Html(f,t,x+SIXELWIDTH,y+SIXEL_AXIS_1*SIXELHEIGHT);
   }

   if(gra.lf3){
      DrawSixel_Html(f,t,x,y+SIXEL_AXIS_2*SIXELHEIGHT);
   }
   if(gra.rt3){
      DrawSixel_Html(f,t,x+SIXELWIDTH,y+SIXEL_AXIS_2*SIXELHEIGHT);
   }
}

void DrawSixel_Html(FILE **f,teletext t,int x,int y)
{
   int rectx,recty,rectw,recth;
   rectx = x;
   recty = y;
   if(t.set.mode == sep_gra ){
      rectw = SIXELWIDTH - FRAMEWIDTH;
      recth =SIXELHEIGHT - FRAMEWIDTH;
   }
   else{
   rectw = SIXELWIDTH;
   recth = SIXELHEIGHT;
   }
   Set_Color_Html(f,t.set.foreground);
   fprintf(*f,"ctx.fillRect(%d,%d,%d,%d);\n",rectx,recty,rectw,recth);
}

void DrawChar_Single_Html(FILE **f, fntrow fontdata[FNTCHARS][FNTHEIGHT],teletext t, int ox, int oy)
{
   unsigned ix, iy;
   unsigned char chr;
   int rectw=CHRWIDTH,recth=CHRHEIGHT;
   chr = t.character-TELESTART;
   for(iy = 0; iy < FNTHEIGHT; iy++){
      for(ix = 0; ix < FNTWIDTH; ix++){
         if(fontdata[chr-FNT1STCHAR][iy] >> (FNTWIDTH - 1 - ix) & 1){
            Set_Color_Html(f,t.set.foreground);
            fprintf(*f,"ctx.fillRect(%d,%d,%d,%d);\n",ix+ox,iy+oy,rectw,recth);
         }
      }
   }
}

/*draw double height character-up*/
void DrawChar_Dup_Html(FILE **f, fntrow fontdata[FNTCHARS][FNTHEIGHT],teletext t, int ox, int oy)
{
   unsigned ix, iy;
   unsigned char chr;
   int rectw=CHRWIDTH,recth=DOUBLE_CHRHEIGHT;
   chr = t.character-TELESTART;
   for(iy = 0; iy < FNTHEIGHT/2; iy++){
      for(ix = 0; ix < FNTWIDTH; ix++){
         if(fontdata[chr-FNT1STCHAR][iy] >> (FNTWIDTH - 1 - ix) & 1){
            Set_Color_Html(f,t.set.foreground);
            fprintf(*f,"ctx.fillRect(%d,%d,%d,%d);\n",ix+ox,2*iy+oy,rectw,recth);
         }
      }
   }
}

/*draw double height character-down*/
void DrawChar_Ddown_Html(FILE **f, fntrow fontdata[FNTCHARS][FNTHEIGHT],teletext t, int ox, int oy)
{
   unsigned ix, iy;
   unsigned char chr;
   int rectw=CHRWIDTH,recth=DOUBLE_CHRHEIGHT;
   chr = t.character-TELESTART;
   for(iy = FNTHEIGHT/2; iy < FNTHEIGHT; iy++){
      for(ix = 0; ix < FNTWIDTH; ix++){
         if(fontdata[chr-FNT1STCHAR][iy] >> (FNTWIDTH - 1 - ix) & 1){
            Set_Color_Html(f,t.set.foreground);
            fprintf(*f,"ctx.fillRect(%d,%d,%d,%d);\n",ix+ox,2*(iy-FNTHEIGHT/2)+oy,rectw,recth);
         }
      }
   }
}
