#include <stdio.h>
#include <stdlib.h>
#include "teletext.h"



int main(int argc,char *argv[])
{
   teletext b[BOARDHEIGHT][BOARDWIDTH];
   if(argc != 2){
      ON_ERROR("The number of Input Error\n");
   }
   Read_telefile(argv[1],b);   
   Setting_Board(b);
   Display_Board(b);

   return 0;
}
 


